﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rubtsova_Diana_RR_31_zd3
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            var inputLines = File.ReadAllLines("input.txt");
            int n = int.Parse(inputLines[0]);
            var diameters = inputLines[1].Split(' ').Select(int.Parse).ToArray();
            var indexedDiameters = diameters.Select((d, i) => new { Diameter = d, Index = i + 1 }).ToArray();
            var sortedDiameters = indexedDiameters.OrderBy(d => d.Diameter).ToArray();
            using (var writer = new StreamWriter("output.txt"))
            {
                for (int i = 0; i < n; i++)
                {
                    int lowerBallIndex = sortedDiameters[i].Index;              
                    int upperBallIndex = sortedDiameters[2 * n - 1 - i].Index; 
                    writer.WriteLine($"{upperBallIndex} {lowerBallIndex}");
                }
            }
            Console.ReadKey();
        }
    }
}
