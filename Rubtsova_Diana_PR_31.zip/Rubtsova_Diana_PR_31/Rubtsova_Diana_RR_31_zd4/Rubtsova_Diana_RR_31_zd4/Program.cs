﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Rubtsova_Diana_RR_31_zd4
{
    internal class Program
    {
        static void Main()
        {
            string[] inputLines = File.ReadAllLines("input.txt");
            string[] firstLine = inputLines[0].Split();
            int messageLength = int.Parse(firstLine[0]);
            int newspaperLength = int.Parse(firstLine[1]);
            string message = inputLines[1];
            string newspaper = inputLines[2];
            string[] messageWords = message.Split(' ');
            string[] newspaperWords = newspaper.Split(' ');
            Dictionary<string, int> wordCount = new Dictionary<string, int>();

            foreach (string word in newspaperWords)
            {
                if (wordCount.ContainsKey(word))
                {
                    wordCount[word]++;
                }
                else
                {
                    wordCount[word] = 1;
                }
            }

            foreach (string word in messageWords)
            {
                if (wordCount.ContainsKey(word) && wordCount[word] > 0)
                {
                    wordCount[word]--;
                }
                else
                {
                    File.WriteAllText("output.txt", word);
                    return;
                }
            }
            File.WriteAllText("output.txt", "GOOD NOTE");
            Console.ReadKey();
        }

    
    }
}
