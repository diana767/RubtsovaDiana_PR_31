﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rubtsova_Diana_RR_31_zd2
{
    internal class Program
    {
        static bool IsPalindrome(string word)
        {
            string upperWord = word.ToUpper();
            for (int i = 0; i < upperWord.Length / 2; i++)
            {
                if (upperWord[i] != upperWord[upperWord.Length - i - 1])
                {
                    return false;
                }
            }
            return true;
        }
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("input.txt");
            StreamWriter sw = new StreamWriter("output.txt");
            int s = int.Parse(sr.ReadLine());
            string[] words = new string[s];
            for (int i = 0; i < s; i++)
            {
                words[i] = sr.ReadLine();
            }
            foreach (string word in words)
            {
                if (IsPalindrome(word))
                {
                    sw.WriteLine("YES");
                }
                else
                {
                    sw.WriteLine("NO");
                }
            }
            sr.Close();
            sw.Close();
            Console.ReadKey();

        }
    }
 }

