﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace Rubtsova_Diana_RR_31_zd5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] input = File.ReadAllLines("input.txt");
            int N = int.Parse(input[0]); 
            string[] parameters = input[1].Split(' ');
            int V = int.Parse(parameters[0]); 
            int t = int.Parse(parameters[1]); 
            int distance = V * t;
            int K = distance % N;
            File.WriteAllText("output.txt", K.ToString());

            Console.ReadKey();
        }
    }
}
